﻿using Microsoft.AspNetCore.Mvc;

namespace test_v01.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }

        public IActionResult Register()
        {
            return View();
        }
    }
}
